package steven.conaway.memory;

import javax.swing.JButton;
import java.awt.Color;
import java.awt.Dimension;

public class PicButton extends JButton {

	private static final long serialVersionUID = 1L;
	private static final int MAXSIZE = 150;
	
	private int row = 0;
	private int col = 0;
	private String id = "";
	//private Boolean hasPic;
	
	public PicButton (int row, int col) {
		this.row = row;
		this.col = col;
		id = Integer.toString(row) + Integer.toString(col);
		System.out.println(id);
		setBackground(Color.BLACK);
		Dimension size = new Dimension(MAXSIZE,MAXSIZE);
		setPreferredSize(size);
		
	}
	
	public int getRow() {
		return row;
	}
	
	public int getCol() {
		return col;
	}
	
	public String getID() {
		return id;
	}
	
	public void setImage() {
		setBackground(Color.RED);
		//hasPic = true;
	}
	
	public void clearImage() {
		setBackground(Color.BLACK);
		//hasPic = false;
	}
}
