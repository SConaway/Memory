/**
 * 
 */
package steven.conaway.memory;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import java.util.ArrayList;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;

/**
 * @author Steven
 *
 */
public class Memory extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final int GRIDSIZE = 4;
	private PicButton[][] liteBut = new PicButton[GRIDSIZE][GRIDSIZE];
	private Random rand = new Random();
	private ClassLoader cl = this.getClass().getClassLoader();
	private String[] imagelist = {"images/image01.jpg", "images/image02.jpg","images/image03.jpg","images/image04.jpg"};
	private ArrayList<String> images = new ArrayList<String>();
	private volatile String icon = "";

	public Memory() {
		initGUI();
		setTitle("Memory");
		setResizable(false);
		pack();
		setLocationRelativeTo(null);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		}
	
	private void initGUI() {
		assignimages();
		TitleLabel framedTitle = new TitleLabel("Memory");
		add(framedTitle, BorderLayout.PAGE_START);
		
		JPanel centerPanel = new JPanel();
		centerPanel.setLayout(new GridLayout(GRIDSIZE, GRIDSIZE));
		add(centerPanel, BorderLayout.CENTER);
		

		
		for (int row=0; row<GRIDSIZE; row++) {
			for (int col=0; col<GRIDSIZE; col++) {
				liteBut[row][col] = new PicButton(row, col);
				
				
				if (row == 0) {
					if (col == 0) {
						icon = images.get(0);
						System.out.println(icon);
					}
					else if (col == 1) {
						icon = images.get(1);
						System.out.println(icon);
					}
					else if (col == 2) {
						icon = images.get(2);
						System.out.println(icon);
					}
					else if (col == 3) {
						icon = images.get(3);
						System.out.println(icon);
					}
					
				}
				else if (row == 1) {
					if (col == 0) {
						icon = images.get(0);
						System.out.println(icon);
					}
					else if (col == 1) {
						icon = images.get(1);
						System.out.println(icon);
					}
					else if (col == 2) {
						icon = images.get(2);
						System.out.println(icon);
					}
					else if (col == 3) {
						icon = images.get(3);
						System.out.println(icon);
					}
					
				}
				
				liteBut[row][col].addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						PicButton button = (PicButton) e.getSource();
						int row = button.getRow();
						int col = button.getCol();
						String id = button.getID();
						System.out.println("Hi from " + id);
						liteBut[row][col].setIcon(new ImageIcon(cl.getResource(icon)));
					}
				});
				centerPanel.add(liteBut[row][col]);
			}
		}
		
		
	}
	private void assignimages() {
		for (int x=0;x<4;x++) {
			int i = rand.nextInt(GRIDSIZE);
			images.add(imagelist[i]);
		}
		for (int x=0;x<images.size();x++) {
			System.out.println(images.get(x));
		}
	}
	
	public static void main(String[] args) {
	  	try {
			String className = UIManager.getCrossPlatformLookAndFeelClassName();
			UIManager.setLookAndFeel(className);
		}
		catch (Exception e) {}
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
			new Memory();
			}
		});
	}
}
